# 题型
* 选择20 
* 填空10
* 程序阅读(每一个空格都是填一行）10
* 代码完形填空 10
* 编程题 50


# 关于编程题
## 输入输出
* 输出
```java
System.out.println()
```
* 输入函数
```java
System.in
```
* 用缓冲区读
```java
import java.util.*;
new Scanner(System.in)
```
* 生成伪随机数
```java
Random//按照从多少到多少到随机数
```
以下是ChatGPT生成的样例：
```java
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        int min = 10; // 下限
        int max = 20; // 上限（不包含）
        int randomNumber = random.nextInt(max - min) + min;
        System.out.println("随机整数: " + randomNumber);
    }
}
```
* 字符串类(String类)
```java
String.split(正则表达式)
```
以下是由ChatGPT生成的样例

基本用法：
```java
public class Main {
    public static void main(String[] args) {
        String str = "apple,orange,banana";
        String[] result = str.split(",");
        for (String s : result) {
            System.out.println(s);
        }
    }
}
```
输出结果
```
apple
orange
banana
```
正则表达式
```java
public class Main {
    public static void main(String[] args) {
        String str = "apple123orange456banana";
        String[] result = str.split("\\d+"); // 按数字拆分
        for (String s : result) {
            System.out.println(s);
        }
    }
}
```
使用limit参数
```java
public class Main {
    public static void main(String[] args) {
        String str = "apple,orange,banana,grape";

        // 限制分割成最多 2 个元素
        String[] result1 = str.split(",", 2);
        for (String s : result1) {
            System.out.println(s);
        }

        // 不限制分割的元素数量（默认）
        String[] result2 = str.split(",", 0);
        for (String s : result2) {
            System.out.println(s);
        }
    }
}
```
统计每个单词出现的频率，最为理想的数据结构：哈希表

实例化HashMap

包装器类Integer





# 懂得都懂系列
## 写方法
* 写一个方法判断一个数是否是素数

* 写一个方法判断一个数字是否是回文数
* 写一个方法判断一个数字是否是完数
* 写一个方法判断一个数字是否是水仙花数(以前没考过，应该不会考)
* 可能会出现从键盘上输入一个数字
```
public class NumberUtils {

    // 判断一个数是否是素数
    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    // 判断一个数字是否是回文数
    public static boolean isPalindrome(int num) {
        int original = num;
        int reversed = 0;
        while (num != 0) {
            int digit = num % 10;
            reversed = reversed * 10 + digit;
            num /= 10;
        }
        return original == reversed;
    }

    // 判断一个数字是否是完数
    public static boolean isPerfectNumber(int num) {
        if (num <= 1) {
            return false;
        }
        int sum = 0;
        for (int i = 1; i <= num / 2; i++) {
            if (num % i == 0) {
                sum += i;
            }
        }
        return sum == num;
    }

    // 判断一个数字是否是水仙花数
    public static boolean isArmstrong(int num) {
        int original = num;
        int sum = 0;
        int digits = (int) Math.log10(num) + 1; // 计算数字的位数
        while (num != 0) {
            int digit = num % 10;
            sum += Math.pow(digit, digits);
            num /= 10;
        }
        return original == sum;
    }

    public static void main(String[] args) {
        // 示例测试
        System.out.println(isPrime(7)); // true
        System.out.println(isPalindrome(121)); // true
        System.out.println(isPerfectNumber(28)); // true
        System.out.println(isArmstrong(153)); // true
    }
}
```
## 第二章

教材P63 2-15   输入一个班的成绩写入到一维数组中，求最高分、平均分，并统计各分数段的人数，其中的分数段有：不及格(<60)、及格(60~69)、中(70~79)、良(80~89)、优(>90)。PS：可能不考成绩，是分出某一个产品的销售额
```java
import java.util.Scanner;
public class ScoreStatistics {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // 输入班级人数
        System.out.print("请输入班级人数: ");
        int n = scanner.nextInt();
        int[] scores = new int[n];
        // 输入成绩
        System.out.println("请输入 " + n + " 个学生的成绩:");
        for (int i = 0; i < n; i++) {
            scores[i] = scanner.nextInt();
        }
        // 初始化统计变量
        int maxScore = Integer.MIN_VALUE;
        int totalScore = 0;
        int failCount = 0, passCount = 0, middleCount = 0, goodCount = 0, excellentCount = 0;
        // 遍历数组，统计最高分、总分和各分数段人数
        for (int score : scores) {
            // 最高分
            if (score > maxScore) {
                maxScore = score;
            }
            // 总分
            totalScore += score;

            // 分数段统计
            if (score < 60) {
                failCount++;
            } else if (score <= 69) {
                passCount++;
            } else if (score <= 79) {
                middleCount++;
            } else if (score <= 89) {
                goodCount++;
            } else {
                excellentCount++;
            }
        }
        // 计算平均分
        double averageScore = totalScore / (double) n;
        // 输出结果
        System.out.println("\n统计结果:");
        System.out.printf("最高分: %d\n", maxScore);
        System.out.printf("平均分: %.2f\n", averageScore);
        System.out.println("分数段统计:");
        System.out.printf("不及格 (<60): %d 人\n", failCount);
        System.out.printf("及格 (60~69): %d 人\n", passCount);
        System.out.printf("中等 (70~79): %d 人\n", middleCount);
        System.out.printf("良好 (80~89): %d 人\n", goodCount);
        System.out.printf("优秀 (>90): %d 人\n", excellentCount);
        scanner.close();
    }
}
```
教材P63 2-19   设有一条绳子，长2000m，每天减去1/3，计算多少天后长度变为1cm。会改数字
```java
public class RopeLengthReduction {
    public static void main(String[] args) {
        // 初始化绳子的初始长度 (以厘米为单位)
        double length = 2000 * 100; // 2000 米 = 200000 厘米
        int days = 0;

        // 每天减少 1/3 的长度，直到长度小于等于 1cm
        while (length > 1) {
            length -= length / 3; // 减少 1/3
            days++; // 记录天数
        }

        // 输出所需的天数
        System.out.println("绳子的长度变为 1cm 所需的天数: " + days);
    }
}
```
## 第三章
教材P79 3-5   考的是员工，不是学生，但是没有区别   并实现当数组满了以后自动扩容
```
编写一个学生类student，包含的属性有学号、姓名、性别、年龄等，将所有学生存储在一个数组中，编写学生管理程序完成如下操作：
1.增加一个学生。2.根据学号删除某个学生。3.将所有学生党年龄增加一岁。4.按数组中顺序显示所有学生党信息。5.将所有的学生按照姓名排序输出。
```
下面代码由ChatGPT生成
```java
import java.util.Scanner;
import java.util.Arrays;

class Student {
    private int id;          // 学号
    private String name;     // 姓名
    private String gender;   // 性别
    private int age;         // 年龄

    // 构造方法
    public Student(int id, String name, String gender, int age) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.age = age;
    }

    // 获取学号
    public int getId() {
        return id;
    }

    // 设置年龄
    public void increaseAge() {
        this.age++;
    }

    // 显示学生信息
    public void display() {
        System.out.printf("学号: %d, 姓名: %s, 性别: %s, 年龄: %d\n", id, name, gender, age);
    }

    // 获取姓名 (用于排序)
    public String getName() {
        return name;
    }
}

public class StudentManager {
    private static Student[] students = new Student[100]; // 最大支持100名学生
    private static int studentCount = 0;                  // 当前学生数

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n学生管理系统");
            System.out.println("1. 增加一个学生");
            System.out.println("2. 根据学号删除学生");
            System.out.println("3. 将所有学生年龄增加一岁");
            System.out.println("4. 显示所有学生信息");
            System.out.println("5. 按姓名排序显示所有学生");
            System.out.println("0. 退出");
            System.out.print("请选择操作: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> addStudent(scanner);
                case 2 -> deleteStudent(scanner);
                case 3 -> increaseAge();
                case 4 -> displayAllStudents();
                case 5 -> sortAndDisplayByName();
                case 0 -> {
                    System.out.println("退出系统！");
                    return;
                }
                default -> System.out.println("无效选择，请重试！");
            }
        }
    }

    // 添加学生
    private static void addStudent(Scanner scanner) {
        if (studentCount >= students.length) {
            System.out.println("学生人数已达上限！");
            return;
        }
        System.out.print("请输入学号: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // 清除换行符
        System.out.print("请输入姓名: ");
        String name = scanner.nextLine();
        System.out.print("请输入性别: ");
        String gender = scanner.nextLine();
        System.out.print("请输入年龄: ");
        int age = scanner.nextInt();

        students[studentCount++] = new Student(id, name, gender, age);
        System.out.println("学生添加成功！");
    }

    // 删除学生
    private static void deleteStudent(Scanner scanner) {
        System.out.print("请输入要删除的学生学号: ");
        int id = scanner.nextInt();
        for (int i = 0; i < studentCount; i++) {
            if (students[i].getId() == id) {
                // 删除操作
                for (int j = i; j < studentCount - 1; j++) {
                    students[j] = students[j + 1];
                }
                students[--studentCount] = null; // 清空最后一个位置
                System.out.println("学生删除成功！");
                return;
            }
        }
        System.out.println("未找到该学号的学生！");
    }

    // 年龄增加一岁
    private static void increaseAge() {
        for (int i = 0; i < studentCount; i++) {
            students[i].increaseAge();
        }
        System.out.println("所有学生年龄增加一岁！");
    }

    // 显示所有学生信息
    private static void displayAllStudents() {
        if (studentCount == 0) {
            System.out.println("当前没有学生！");
            return;
        }
        System.out.println("所有学生信息：");
        for (int i = 0; i < studentCount; i++) {
            students[i].display();
        }
    }

    // 按姓名排序并显示
    private static void sortAndDisplayByName() {
        if (studentCount == 0) {
            System.out.println("当前没有学生！");
            return;
        }
        // 排序
        Arrays.sort(students, 0, studentCount, (s1, s2) -> s1.getName().compareTo(s2.getName()));

        System.out.println("按姓名排序后的学生信息：");
        for (int i = 0; i < studentCount; i++) {
            students[i].display();
        }
    }
}
```
## 第四章
教材P118 4-11编写一个抽象类表示形状，其中有一个求面积的抽象方法，继承该抽象方法分别编写三角形、圆、矩形类，创建一个数组存放创建的各类徒刑对象，输出图形的面积。

以下内容由ChatGPT生成：
```java
// 定义一个抽象类 Shape 表示形状
abstract class Shape {
    // 抽象方法：求面积
    public abstract double getArea();
}

// 三角形类
class Triangle extends Shape {
    private double base;  // 底边
    private double height; // 高

    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    @Override
    public double getArea() {
        return 0.5 * base * height; // 面积公式：0.5 * 底 * 高
    }
}

// 圆类
class Circle extends Shape {
    private double radius; // 半径

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius; // 面积公式：π * 半径²
    }
}

// 矩形类
class Rectangle extends Shape {
    private double length; // 长
    private double width;  // 宽

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double getArea() {
        return length * width; // 面积公式：长 * 宽
    }
}

// 测试类
public class Main {
    public static void main(String[] args) {
        // 创建图形对象数组
        Shape[] shapes = new Shape[3];

        // 创建不同的图形对象并存入数组
        shapes[0] = new Triangle(10, 5);     // 三角形，底边为 10，高为 5
        shapes[1] = new Circle(7);          // 圆，半径为 7
        shapes[2] = new Rectangle(4, 6);    // 矩形，长为 4，宽为 6

        // 遍历数组并输出每个图形的面积
        for (Shape shape : shapes) {
            System.out.println("面积: " + shape.getArea());
        }
    }
}
```
## 第十章 Applet等图形化
哪怕有必要用图形应用接口，起码使用swing，

* 教材 P248 10-7 编写选好程序，在窗体中安排6个标签，每个标签上显示0～9之间的一位数字，每位数字用一个线程控制其变化，单击“停止”则所有标签数字停止变化。swing

以下内容由ChatGPT生成
```java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NumberChanger extends JFrame {
    private JLabel[] labels = new JLabel[6];  // 6 个标签
    private Thread[] threads = new Thread[6]; // 每个标签对应一个线程
    private boolean running = true;          // 控制线程是否运行

    public NumberChanger() {
        // 设置窗口标题、布局和关闭操作
        setTitle("数字变化程序");
        setLayout(new GridLayout(2, 3, 10, 10)); // 网格布局：2 行 3 列
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);

        // 创建标签并添加到窗口中
        for (int i = 0; i < labels.length; i++) {
            labels[i] = new JLabel("0", SwingConstants.CENTER); // 标签默认显示 "0"
            labels[i].setFont(new Font("Arial", Font.BOLD, 30)); // 设置字体和大小
            labels[i].setBorder(BorderFactory.createLineBorder(Color.BLACK));
            add(labels[i]);
        }

        // 创建并启动每个标签对应的线程
        for (int i = 0; i < threads.length; i++) {
            final int index = i; // 保存索引供线程使用
            threads[i] = new Thread(() -> {
                while (true) {
                    if (!running) break; // 如果运行标志为 false，退出线程
                    int randomNum = (int) (Math.random() * 10); // 生成随机数字 0～9
                    labels[index].setText(String.valueOf(randomNum)); // 更新标签
                    try {
                        Thread.sleep(500); // 每隔 500 毫秒更新一次
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt(); // 恢复中断状态
                        break;
                    }
                }
            });
            threads[i].start(); // 启动线程
        }

        // 创建 "停止" 按钮
        JButton stopButton = new JButton("停止");
        stopButton.setFont(new Font("Arial", Font.BOLD, 20));
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                running = false; // 设置运行标志为 false
            }
        });

        // 添加按钮到窗口
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(stopButton);
        add(buttonPanel);

        // 显示窗口
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(NumberChanger::new); // 启动程序
    }
}
```
用的是JPanel包。

关于volitile关键字，以下内容由ChatGPT生成：
```
class StopThread {
    private volatile boolean stop = false;

    public void stopThread() {
        stop = true;
    }

    public void run() {
        while (!stop) {
            // 线程运行
        }
    }
}
```

"""
main.py

程序入口
"""

from parser.newick_parser import parse_newick
from analysis.monophyly_checker import (
    check_strict_monophyly,
    check_tolerant_monophyly
)

from utils.file_utils import load_tree_files, read_file
from stats.statistics import ResultStats
import config


def main():

    files = load_tree_files(config.TREE_DIR)

    stats = ResultStats()

    for path in files:

        newick = read_file(path)

        root = parse_newick(newick)

        strict, reason = check_strict_monophyly(
            root,
            config.TARGET_GROUP
        )

        tolerant, missing = check_tolerant_monophyly(
            root,
            config.TARGET_GROUP,
            config.TOLERANCE_K
        )

        print("\n", path)
        print("strict:", strict)
        print("tolerant:", tolerant)
        print("missing samples:", missing)

        stats.add_result(strict, tolerant, missing)

    stats.print_summary()


if __name__ == "__main__":
    main()
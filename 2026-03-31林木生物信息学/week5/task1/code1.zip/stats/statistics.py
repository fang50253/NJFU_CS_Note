"""
statistics.py

统计严格比例、宽松比例、异常样本
"""

from collections import defaultdict


class ResultStats:

    def __init__(self):

        self.total = 0
        self.strict_pass = 0
        self.tolerant_pass = 0

        # 记录失败样本
        self.failure_samples = defaultdict(int)

    def add_result(self, strict, tolerant, missing_samples):

        self.total += 1

        if strict:
            self.strict_pass += 1

        if tolerant:
            self.tolerant_pass += 1

        for s in missing_samples:
            self.failure_samples[s] += 1

    def print_summary(self):

        print("\n===== 总统计 =====")

        print("树总数:", self.total)

        print("Strict比例:",
              self.strict_pass / self.total)

        print("Tolerant比例:",
              self.tolerant_pass / self.total)

        print("\n最容易破坏单系的样本:")

        for k, v in sorted(self.failure_samples.items(),
                           key=lambda x: -x[1]):

            print(k, v)